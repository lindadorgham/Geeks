package com.application.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.application.model.Logiciel;
import com.application.repository.LogicielRepository;



@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
@RequestMapping("/api/logiciel")
public class LogicielController {
private final LogicielRepository logicielRepository;
	
	
	@Autowired
	public LogicielController(LogicielRepository logicielRepository) {
		this.logicielRepository = logicielRepository;
	}
	
	@GetMapping("/list")
	public List<Logiciel>  getSystemsList() {
		return this.logicielRepository.findAll();
		
	}
	
	
	
	
	
		
		
	
	
	
	
	
}

