package com.application.model;

public enum  RoleName {
    ROLE_USER,
    ROLE_ADMIN,
}