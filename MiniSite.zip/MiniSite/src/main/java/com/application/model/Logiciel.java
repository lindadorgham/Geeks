package com.application.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "logiciel", uniqueConstraints = {
    @UniqueConstraint(columnNames = {
        "code"
    })
})
public class Logiciel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long code;

    @NotBlank
    @Size(min = 3, max = 50)
    private String nom;
    @NotBlank
    @Size(min = 3, max = 500)
    private String description;
    @NotBlank
   
    private String image;
    
	
	public Long getCode() {
		return code;
	}


	public void setCode(Long code) {
		this.code = code;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public String getImage() {
		return image;
	}


	public void setImage(String image) {
		this.image = image;
	}


	public Logiciel(Long code, @NotBlank @Size(min = 3, max = 50) String nom,
			@NotBlank @Size(min = 3, max = 500) String description, @NotBlank String image) {
		super();
		this.code = code;
		this.nom = nom;
		this.description = description;
		this.image = image;
	}


	public Logiciel() {
		super();
	}
    
}
