package com.application.message.response;


import java.util.Optional;

import com.application.model.User;

public class JwtResponse {
    private String token;
    private String type = "Bearer";
    private Optional<User> info;
    
     public JwtResponse(String accessToken, Optional<User> user) {
        this.token = accessToken;
        this.info=user;
    }

    public JwtResponse(String accessToken) {
        this.token = accessToken;
    }

    public String getAccessToken() {
        return token;
    }

    public void setAccessToken(String accessToken) {
        this.token = accessToken;
    }

    public String getTokenType() {
        return type;
    }

    public void setTokenType(String tokenType) {
        this.type = tokenType;
    }

    /**
     * @return the info
     */
    public Optional<User> getInfo() {
        return info;
    }

    /**
     * @param info the info to set
     */
    public void setInfo(Optional<User> info) {
        this.info = info;
    }
}